﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scientific_Calculator
{

    class Program
    {
    //main method
        static void Main(string[] args)
        {
            HandleInput ui = new HandleInput();
            ui.Start();
        }
    }

}
