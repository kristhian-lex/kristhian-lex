﻿using System;

namespace Scientific_Calculator
{
    //class for trigonometric
    public class TrigonometricOperations
    {
        public double Sin(double angle) { return Math.Sin(angle); }
        public double Cos(double angle) { return Math.Cos(angle); }
        public double Tan(double angle) { return Math.Tan(angle); }
    }


}
