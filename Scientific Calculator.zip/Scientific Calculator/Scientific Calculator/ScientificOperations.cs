﻿using System;

namespace Scientific_Calculator
{
    //class for scientific
    public class ScientificOperations
    {
        public double SquareRoot(double a) { return Math.Sqrt(a); }
        public double Power(double a, double b) { return Math.Pow(a, b); }
    }


}
